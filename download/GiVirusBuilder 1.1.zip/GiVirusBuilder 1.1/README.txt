LANGUAGE: English

ATTENTION!!! Please read the instructions carefully before using this program!
By using this program you agree to all the terms and conditions listed below!

This is a simple and unique program GiVirusBuilder 1.1
With this program you can create or generate bat viruses!

CONDITIONS: 
We are not responsible for any of your actions!
If any problems occur, the program will not be involved in them!

HOW TO USE THE PROGRAM CORRECTLY?
- Select method-creating the virus.
- To select an action, you need to enter the index (number) of the action (for example: 1 )... 
- If you select "CREATE MANUALLY" , you will see a list of options for the virus.
- Then just select the options by specifying their numbers and the code is automatically registered in the created file
- When you want to finish working with the virus, enter "0" 
- Done! The virus was successfully created! 

NOTE:
- The virus file is saved in the current program directory!!! 

IN ORDER FOR THE PROGRAM TO WORK CORRECTLY YOU NEED TO:
- To manage the program, you need to enter the action numbers.
- Disable anti-virus 

THE PROGRAM IS IN INITIAL DEVELOPMENT ALL BUGS ARE FIXED WITH EACH NEW VERSION!
STAY TUNED!) 
SUCCESSFUL POLZAVANIYA!!! 
GiVirusBuilder 1.1
BY TUSSA

***************************************

LANGUAGE: Русский (Russian) 

ВНИМАНИЕ!!! Перед пользаванием данной программой прочтите внимательно инкструкцию!
Пользуясь этой программой вы соглашаетесь со всеми условиями указаными ниже!

Это простая и уникальная программа GiVirusBuilder 1.1
С помощью этой программы вы сможете создавать или генерировать бат вирусы!

УСЛОВИЯ:
Мы не несем ответственость за какие либо ваши действия!
При возникновении каких либо проблем, программа не будет причастна к ним!

КАК ПРАВИЛЬНО ПОЛЬЗОВАТЬСЯ ПРОГРАММОЙ?
- Выберите способ создание вируса.
- Что бы выбрать какое-либо действия, нужно ввести индефикатор(число) действия (например: 1 )...
- Если вы выбрали "CREATE MANUALLY" то у вас появиться список опций для вируса.
- Дальше просто выбираете опции указывая их номера и код автоматически прописываеться в созданный файл
- Когда вы захотите заверщить работу с вирусом, введите "0"
- Готово! Вирус успешно создан!

ЗАМЕТКА:
- Файл вируса сохраняеться в текущем каталоге программы!!!

ЧТО БЫ ПРОГРАММА РАБОТАЛА ПРАВИЛЬНО НУЖНО:
- Для управления программой надо вписывать номера действий.
- Отключить анти-вирус

ПРОГРАММА В НАЧАЛЬНОЙ РАЗРАБОТКЕ ВСЕ БАГИ ИСПРАВЛЯЮТЬСЯ С КАЖДОЙ НОВОЙ ВЕРСИЕЙ!
СЛЕДИТЕ ЗА ОБНОВЛЕНИЯМИ!)
УДАЧНОГО ПОЛЬЗОВАНИЯ!!!
GiVirusBuilder 1.1
BY TUSSA


